(function(){console.log("fuck")});
